const forceBans = require("../../SystemModels/forceBans");
const { red, green, Cezaa, Revuu, kirmiziok } = require("../../Settings/emojis.json");
const moment = require("moment");
moment.locale("tr");

module.exports = {
  conf: {
    aliases: ["unforceban", "forceunban"],
    name: "unforceban",
    help: "unforceban <UserID>",
    category: "sahip",
    owner: true
  },

  run: async (client, message, args, embed) => {
    const user = await client.fetchUser(args[0]);
    if (!user) return message.channel.send({ content: "Lütfen bir kullanıcı ID'si belirtin." }).then((e) => setTimeout(() => { e.delete(); }, 5000));
    const ban = await forceBans.findOne({ guildID: message.guild.id, userID: user.id });
    if (!ban) return message.channel.send({ content: "Bu kullanıcı zaten force-banlanmamış." }).then((e) => setTimeout(() => { e.delete(); }, 5000));

    message.guild.bans.remove(user.id).catch(() => {});
    await forceBans.deleteOne({ guildID: message.guild.id, userID: user.id });

    message.react(green)
    message.channel.send({ content: `${user.tag} adlı kullanıcının force-banı başarıyla kaldırıldı!` }).then((e) => setTimeout(() => { e.delete(); }, 10000));

    const log = embed
      .setDescription(`
${Cezaa} Banı Kaldırılan Üye: ${user.tag} \`${user.id}\`
${Revuu} Banı Kaldıran Yetkili: ${message.author} \`${message.author.id}\`
      `)
      .setFooter({ text:`${moment(Date.now()).format("LLL")}` });
    message.guild.channels.cache.get(conf.banLogChannel).send({ embeds: [log] });
  },
};
