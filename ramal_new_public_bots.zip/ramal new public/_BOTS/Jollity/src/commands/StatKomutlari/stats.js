const { MessageAttachment, MessageEmbed, MessageActionRow, MessageSelectMenu } = require("discord.js");
const conf = require("../../Settings/sunucuayar.json")
const { voice, mesaj2, star, miniicon } = require("../../Settings/emojis.json");
const messageUserChannel = require("../../SystemModels/messageUserChannel");
const voiceUserChannel = require("../../SystemModels/voiceUserChannel");
const messageUser = require("../../SystemModels/messageUser");
const voiceUser = require("../../SystemModels/voiceUser");
const voiceUserParent = require("../../SystemModels/voiceUserParent");
const isimler = require("../../SystemModels/names");
const register = require("../../SystemModels/registerStats");
const inviterSchema = require("../../SystemModels/inviter");
const inviteMemberSchema = require("../../SystemModels/inviteMember");
const ms = require("../../SystemModels/LastMeesage");
let { Stats, Seens } = require('../../SystemModels/Tracking');
const moment = require("moment");
require("moment-duration-format");
const Canvas = require("canvas");
const { registerFont } = require("canvas");
registerFont('./MarlinGeo-Black.otf', { family: 'Marlin Geo Black' })
const wait = require('node:timers/promises').setTimeout;

module.exports = {
    conf: {
      aliases: ["mes","stats"],
      name: "stats",
      help: "stats",
      category: "stat",
    },
  
run: async (client, message, args, prefix) => {
  let kanallar = conf.chatChannel;
  if (!message.member.permissions.has(8n) && kanallar.includes(message.channel.id)) return message.reply({ content: `Bu komutu chatte kullanamazsın, bot komut kanallarını kullanınız`, ephemeral: true }).then((e) => setTimeout(() => { e.delete(); }, 10000)); 

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const inviterData = await inviterSchema.findOne({ guildID: message.guild.id, userID: member.user.id });
    const total = inviterData ? inviterData.total : 0;
    const regular = inviterData ? inviterData.regular : 0;
    const bonus = inviterData ? inviterData.bonus : 0;
    const leave = inviterData ? inviterData.leave : 0;
    const fake = inviterData ? inviterData.fake : 0;
    const invMember = await inviteMemberSchema.find({ guildID: message.guild.id, inviter: member.user.id });
    const daily = invMember ? message.guild.members.cache.filter((m) => invMember.some((x) => x.userID === m.user.id) && Date.now() - m.joinedTimestamp < 1000 * 60 * 60 * 24).size : 0;
    const weekly = invMember ? message.guild.members.cache.filter((m) => invMember.some((x) => x.userID === m.user.id) && Date.now() - m.joinedTimestamp < 1000 * 60 * 60 * 24 * 7).size : 0;
    let msj = await ms.findOne({guildId: message.guild.id, userID: member.id})
    let tagged;
    if (conf.tag && conf.tag.length > 0) tagged = invMember ? message.guild.members.cache.filter((m) => invMember.some((x) => x.userID === m.user.id) && tagges.some(tag => m.user.tag.includes(tag))).size : 0;
    else tagged = 0;
    let seens = await Seens.findOne({userID: member.user.id});

    const category = async (parentsArray) => {
        const data = await voiceUserParent.find({ guildID: message.guild.id, userID: member.id });
        const voiceUserParentData = data.filter((x) => parentsArray.includes(x.parentID));
        let voiceStat = 0;
        for (var i = 0; i <= voiceUserParentData.length; i++) {
          voiceStat += voiceUserParentData[i] ? voiceUserParentData[i].parentData : 0;
        }
        return moment.duration(voiceStat).format("H [saat], m [dakika] s [saniye]");
      };
      
      const Active1 = await messageUserChannel.find({ guildID: message.guild.id, userID: member.id }).sort({ channelData: -1 });
      const Active2 = await voiceUserChannel.find({ guildID: message.guild.id, userID: member.id }).sort({ channelData: -1 });
      let messageTop;
      const voiceLength = Active2 ? Active2.length : 0;
      let voiceTop;
      Active1.length > 0 ? messageTop = Active1.splice(0, 5).map(x => `${miniicon} <#${x.channelID}>: \`${Number(x.channelData).toLocaleString()} mesaj\``).join("\n") : messageTop = "Veri bulunmuyor."
      Active2.length > 0 ? voiceTop = Active2.splice(0, 5).map(x => `${miniicon} <#${x.channelID}>: \`${moment.duration(x.channelData).format("H [saat] m [dakika] s [saniye]")}\``).join("\n") : voiceTop = "Veri bulunmuyor.";
      const messageData = await messageUser.findOne({ guildID: message.guild.id, userID: member.id });
      const voiceData = await voiceUser.findOne({ guildID: message.guild.id, userID: member.id });
      const messageWeekly = messageData ? messageData.weeklyStat : 0;
      const voiceWeekly = moment.duration(voiceData ? voiceData.weeklyStat : 0).format("H [saat], m [dakika]");
      const messageDaily = messageData ? messageData.dailyStat : 0;
      const voiceDaily = moment.duration(voiceData ? voiceData.dailyStat : 0).format("H [saat], m [dakika]");

      const applyText = (canvas, text) => {
        const ctx = canvas.getContext('2d');
    
        let fontSize = 70;
    
        do {
            ctx.font = `${fontSize -= 10}px sans-serif`;
        } while (ctx.measureText(text).width > canvas.width - 300);
    
        return ctx.font;
    };
    const canvas = Canvas.createCanvas(1280, 400);
        const ctx = canvas.getContext('2d');
    
     let ramalcimm = ["https://cdn.discordapp.com/attachments/1009804086293565501/1093987380714799154/ramalastatss.png","https://cdn.discordapp.com/attachments/1009804086293565501/1093987238972489768/ramalstatssss.png","https://cdn.discordapp.com/attachments/1009804086293565501/1093987069019312128/ramalstats.png","https://cdn.discordapp.com/attachments/1009804086293565501/1093987619999850496/ramalaaistestats.png"]
     let ramalcikk = Math.floor((Math.random() * ramalcimm.length));
    
        const background = await Canvas.loadImage(ramalcimm[ramalcikk]);  
        ctx.save();
        roundedImage(ctx, 0, 0, 1280, 400, 50);
        ctx.clip();
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
        ctx.closePath();
    
        ctx.strokeStyle = '#ffffff';
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
    
    
     
    
    
  
    //${moment(member.user.createdAt).format(`DD/MM/YYYY`)}

    //${moment(mmember.joinedAt).format(`DD/MM/YYYY`)}
        ctx.font = '34px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${member.user.tag}`, canvas.width / 10, canvas.height / 5);

        ctx.font = '27px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment(member.user.createdAt).format(`DD/MM/YYYY`)}`, canvas.width / 1.62, canvas.height / 4.4);

        ctx.font = '27px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment(member.joinedAt).format(`DD/MM/YYYY`)}`, canvas.width / 1.21, canvas.height / 4.4);


        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment.duration(voiceData ? voiceData.topStat : 0).format("H [s], m [dk], s [sn]") || "Veri yok."}`, canvas.width / 5, canvas.height / 1.80);
      
        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${messageData ? messageData.topStat : 0}`, canvas.width / 5, canvas.height / 1.41);
      
        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`Ayarlanacak`, canvas.width / 5, canvas.height / 1.18);
          


        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${messageData ? messageData.topStat : 0}`, canvas.width / 1.90, canvas.height / 1.18);
      
        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${Number(messageWeekly).toLocaleString()}`, canvas.width / 1.90, canvas.height / 1.80);
        
        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${Number(messageDaily).toLocaleString()}`, canvas.width / 1.90, canvas.height / 1.43);
        //${moment.duration(voiceData ? voiceData.topStat : 0).format("H [s], m [dk], s [sn]") || "Veri yok."}
    

        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment.duration(voiceData ? voiceData.dailyStat : 0).format("H [s], m [dk], s [sn]") || "Veri yok."}`, canvas.width / 1.18, canvas.height / 1.18);

        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment.duration(voiceData ? voiceData.topStat : 0).format("H [s], m [dk], s [sn]") || "Veri yok."}`, canvas.width / 1.18, canvas.height / 1.80);
        
        ctx.font = '16px "Marlin Geo Black"',
        ctx.fillStyle = '#e0e0e0';
        ctx.fillText(`${moment.duration(voiceData ? voiceData.weeklyStat : 0).format("H [s], m [dk], s [sn]") || "Veri yok."}`, canvas.width / 1.18, canvas.height / 1.43);


      ////////////////bitiş////////////////////////////////////////////////  
          const avatar = await Canvas.loadImage(member.user.displayAvatarURL({ format: 'png' }));
     ctx.save();
      roundedImage(ctx, 40, 35, 65, 65, 15);
        ctx.clip();
      ctx.drawImage(avatar, 40, 35, 80, 80);
      ctx.closePath();
    
      // Clip off the region you drew on
      ctx.clip();
     
      function roundedImage(ctx, x, y, width, height, radius) {
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    }

      if (member.user.bot) return;
  
      let nameData = await isimler.findOne({ guildID: message.guild.id, userID: member.id });
      let registerData = await register.findOne({ guildID: message.guild.id, userID: member.id });
    
               const roles = member.roles.cache.filter(role => role.id !== message.guild.id).sort((a, b) => b.position - a.position).map(role => `<@&${role.id}>`);
                const rolleri = []
                if (roles.length > 6) {
                    const lent = roles.length - 6
                    let itemler = roles.slice(0, 6)
                    itemler.map(x => rolleri.push(x))
                    rolleri.push(`${lent} daha...`)
                } else {
                    roles.map(x => rolleri.push(x))
                }
                const members = [...message.guild.members.cache.filter(x => !x.user.bot).values()].sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
                const joinPos = members.map((u) => u.id).indexOf(member.id);
                const previous = members[joinPos - 1] ? members[joinPos - 1].user : null;
                const next = members[joinPos + 1] ? members[joinPos + 1].user : null;
                const bilgi = `${previous ? `**${previous.tag}** > ` : ""}<@${member.id}>${next ? ` > **${next.tag}**` : ""}`
                let üye = message.guild.members.cache.get(member.id)
                let nickname = üye.displayName == member.username ? "" + member.username + " [Yok] " : member.displayName
    
      const yazı = [] 
      if(member.user.username.length > 15) {
      let yarrak = member.user.username.slice(0, 15)
         yazı.push(`${yarrak}...`)  
        } else {
        yazı.push(`${member.user.tag}`)
        }

        const attachment = new MessageAttachment(canvas.toBuffer(), 'xsxs.png');
        message.channel.send({embeds: [new MessageEmbed().setColor("RANDOM").setImage("attachment://xsxs.png")
.setDescription(`${member} kullanıcısının istatistik bilgileri;

**Toplam Kategori Bilgileri (${moment.duration(voiceData ? voiceData.topStat : 0).format("H [s], m [dk], s [sn]") || "0"})**
${miniicon} ${message.guild.name} Public Odalar: \`${await category(conf.publicParents)}\`
${miniicon} ${message.guild.name} Register: \`${await category(conf.registerParents)}\`
${miniicon} ${message.guild.name} Alone: \`${await category(conf.aloneParents)}\`

**Toplam Mesaj Kanal Sıralaması**
${voiceTop}

**Toplam Mesaj Kanal Sıralaması (${messageData ? messageData.topStat : 0})**
${messageTop}

**Diğer Bilgiler**
Toplam Davet (**regular**): \`${regular}\`
Toplam Taglı: \`${tagged}\`
`)], files:[attachment]})
         }}
    
