const { MessageEmbed, Client, Message, MessageActionRow, MessageSelectMenu } = require("discord.js");
const Discord = require('discord.js');
const client = global.bot;
const { star } = require("../../Settings/emojis.json")
const allah = require("../../../../../settings");
const messageUser = require("../../SystemModels/messageUser");

module.exports = {
  conf: {
    aliases: ["info"],
    name: "info",
    help: "info",
    category: "sahip",
    owner: true,
  },
 
    run: async (client, message, args, prefix) => {
 
			const genel = new MessageActionRow()
			.addComponents(
			  new MessageSelectMenu()
				.setCustomId('genel')
				.setPlaceholder('Kurallar hakkında bilgi almak için tıkla!')
				.addOptions([
				  {
					label: "Sunucu Kuralları",
					description: 'Sunucu içerisinde ki genel kuralları görmek için tıkla!',
					value: 'kurallar',
				  },
				]),
			);
            message.channel.send({embeds:[new MessageEmbed().setDescription(`\`${message.guild.name}\` 

            \`••❯\` **Sunucumuzda Kayıt Olmak İçin Ses Teyit Girip Yetkililerimizi beklemen yeterlidir**
     
            \`••❯\` **Sunucu Tagımızı alıp Bizlere Destekte Bulunabilirsin Ve Taglılara Özel Çekilişler ve Etkinliklere Katılma Şansı Yakalayabilirsin**
            
            \`••❯\` **Sunucumuza Boost Basarak Sunucuya Destekte Bulunabilirsin Ve Bunun Yanında Boosterlara Özel Birsürü Şeyden Yaralranabilirsin**
            
            \`••❯\`**Sunucumuzda Kesinlikle Küfür Hakaret Arga VB Şeyler Yasaktır Uyulmadığı Taktirde Mute Veya jail Cezalarına Çarptırılırsınız**
            
            \`••❯\` **Kayıt Olduktan Sonra Kurallarımızı Ve Cezai İşlem Kanalından Cezaları Okuyup Rol alma kanallarından rollerini alabilirsin**
            
            \`••❯\` **Primcilere / Sanal Mafyalara / Ucubelere & Toxic İnsanlara Kesinlikle Yer Yoktur**
            
            \`Aşağıdaki Gördüğünüz Menüden Sunucu İçi Kurallarımızı Kolaylıkla Öğrenebilirsiniz\``)]})
     await message.channel.send({ content :`
    `, components: [genel] });

    },
  };

  client.on('interactionCreate', interaction => {
   
    

    if (!interaction.isSelectMenu()) return;

if (interaction.values[0] === "kurallar") {
    
    interaction.reply({ content : `

    **KURALLAR**

    **Reklam**
    
    • \`Sözlü reklamlar, link ile reklam, özelden reklam, resim ile reklam ve benzeri şekilde reklamlar yapmak yasaktır.\`
    
    **Küfür, Argo, Hakaret**
    
    • \`Her kanalda küfür etmek ve argo kullanmak yasaktır.\`
    • \`Üyelere karşı hakaret etmek ve dalga geçme yasaktır.\`
    
    **Yetkililer ve Yetki**
    
    • \`Yetki istemek yasaktır.\`
    • \`Yetkili alımları ile ilgili soru sormak yasaktır.\`
    • \`Yetkilileri boş yere @etiketlemek ve @etiketleyerek spam yapmak yasaktır.\`
    • \`Yetkililere saygılı olun.\`
    
    **Spam, Flood, Etiketleme**
    
    • \`Spam yapmak yasaktır.\`
    • \`Bir kelimeyi sürekli bir mesajda yazmak yasaktır.\`
    • \`Flood yapmak alt alta yazmak yasaktır.\`
    • \`Bir üyeyi sürekli @etiketlemek yasaktır.\`
    
    **Din, Siyaset, Cinsellik**
    
    • \`Din ile ilgili konuşmak, tartışmak, kullanıcı adlarını din ile ilgili koymak yasaktır.\`
    • \`Siyaset ile ilgili konuşmak, tartışmak, kullanıcı adlarını siyaset ile ilgili koymak yasaktır.\`
    • \`18+ fotoğraflar paylaşmak ve konuşmak yasaktır.\`
    
    **Kavga, Tartışmak**
    
    • \`Kavga etmek, kavgaya dahil olmak ve tartışmak yasaktır.\`
    • \`Herhangi bir sorununuz varsa yetkiliye danışınız\`

`, ephemeral: true })
};


});
      
