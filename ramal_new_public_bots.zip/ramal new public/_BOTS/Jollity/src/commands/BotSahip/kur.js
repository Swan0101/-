const { Database } = require("ark.db");
const db = new Database("/src/Settings/emojis.json");
const { MessageActionRow, MessageButton } = require("discord.js");
const allah = require("../../../../../settings");

module.exports = {
  conf: {
    aliases: [],
    name: "kurulum",
    help: "kurulum",
    category: "sahip",
    owner: true,
  },

  run: async (client, message, args) => {

    if (message.guild === null) {
      return message.reply({ content: `Bu komutu sadece Sunucuda kullanabilirsin!`, ephemeral: true })
    } else if (!allah.Root.includes(message.author.id)) {
      return message.reply({ content: "Bu Komutu Sadace BotOwner Kullana Bilir", ephemeral: true })
    } else {

  const row = new MessageActionRow()
  .addComponents(
  new MessageButton()
  .setCustomId("rol")
  .setLabel("Rol Kur")
  .setStyle("SECONDARY"),

  new MessageButton()
  .setCustomId("kanal")
  .setLabel("Log Kur")
  .setStyle("SECONDARY"),

  new MessageButton()
  .setCustomId("emoji")
  .setLabel("Emoji Kur")
  .setStyle("SECONDARY"),
  );

      let msg = await message.channel.send({ content: `\`Emoji\` - \`Log Kanalı\` - \`Rol\` Kurulumu İçin Butonları Kullanın.`, components: [row]})

      var filter = (button) => button.user.id === message.author.id;
      const collector = msg.createMessageComponentCollector({ filter, componentType: 'BUTTON', max: 3, time: 60000 })


      collector.on("collect", async interaction => {

        if (interaction.customId === "rol") {
          await interaction.deferUpdate();

         await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });
  
          await interaction.guild.roles.create({
            name: "🍓",
            color: "#ff0000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🍊",
            color: "#ff8b00",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🍇",
            color: "#4f00ff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🍑",
            color: "#ff00d1",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🥑",
            color: "#56ff00",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "Alone 💔",
            color: "#b0d0f7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "Couple 💍",
            color: "#e73084",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "Çekiliş Katılımcısı 🎉",
            color: "#f89292",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "Etkinlik Duyuru 🎉",
            color: "#f89292",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♏ Akrep",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♉ Boğa",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♍ Başak",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♊ İkizler",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♒ Kova",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♈ Koç",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♋ Yengeç",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♑ Oğlak",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♎ Terazi",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♌ Aslan",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♓ Balık",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "♐ Yay",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 CS:GO",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 League of Legends",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 Valorant",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 Gta V",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 PUBG",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "🎮 Fortnite",
            color: "#ffa7a7",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          await interaction.guild.roles.create({
            name: "------------------------",
            color: "#000000",
            permissions: "0",
            reason: "Rol Kuruldu"
          });

          msg.reply({ content: `Menü için gerekli Rollerin kurulumu başarıyla tamamlanmıştır.\n**Not:** Renk rollerini booster ve taglı rollerinin üstüne taşıyınız.`, ephemeral: true })

        }

        if (interaction.customId === "kanal") {
          await interaction.deferUpdate();

          const parent = await interaction.guild.channels.create('SUNUCU LOGLAR', {
            type: 'GUILD_CATEGORY',
            permissionOverwrites: [{
              id: interaction.guild.id,
              deny: ['VIEW_CHANNEL'],
            }]
          });
          await interaction.guild.channels.create('level_bilgi', {
            type: 'GUILD_TEXT',
            parent: parent.id,
            permissionOverwrites: [{
            id: interaction.guild.id,
            allow: ['VIEW_CHANNEL'],
            deny: ['SEND_MESSAGES'],
          }]
          });
          await interaction.guild.channels.create('sekme_guard_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('mute_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('jail_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('ban_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('vmute_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('message_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('voice_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('taglı_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('name_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('rank_log', {
            type: 'GUILD_TEXT',
            parent: parent.id

          });
          await interaction.guild.channels.create('market_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('rol_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('yetki_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });
          await interaction.guild.channels.create('komut_log', {
            type: 'GUILD_TEXT',
            parent: parent.id
          });

          msg.reply({ content: `Log Kanallarının kurulumu başarıyla tamamlanmıştır.`, ephemeral: true })

        }

        if (interaction.customId === "emoji") {
          await interaction.deferUpdate();

          const emojis = [
            { name: "star", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763816050663586/Yldzz.gif" },
            { name: "rewards", url: "https://cdn.discordapp.com/emojis/899680521951514734.gif?size=44" },
            { name: "revusome", url: "https://cdn.discordapp.com/emojis/901441419363889172.png?size=96" },
            { name: "miniicon", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763815459266660/stat_icon.png" },
            { name: "red", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763816776278158/red.png" },
            { name: "green", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763816574943362/onay.png" },
            { name: "staff", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763815849328730/yldz_icon.png" },
            { name: "Muhabbet", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763766704685168/kukkanc.png" },
            { name: "galp", url: "https://cdn.discordapp.com/emojis/899680513806184570.gif?size=44" },
            { name: "kirmiziok", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763744546173018/Icon.png" },
            { name: "Revuu", url: "https://media.discordapp.net/attachments/1006698954248966336/1069763815849328730/yldz_icon.png" },
            { name: "Mute", url: "https://cdn.discordapp.com/emojis/901441287469809706.png?size=44" },
            { name: "Cezaa", url: "https://cdn.discordapp.com/attachments/1006698954248966336/1069769742371520633/801553869518798878.gif" },
            { name: "Jail", url: "https://cdn.discordapp.com/emojis/903566151727087686.png?size=96" },
            { name: "Book", url: "https://cdn.discordapp.com/emojis/840123952324149248.webp?size=96&quality=lossless" },
            { name: "Kilit", url: "https://cdn.discordapp.com/emojis/903564832387760128.png?size=96" },
            { name: "Mute2", url: "https://cdn.discordapp.com/emojis/899339342986739802.png?size=96" },
            { name: "Unmute", url: "https://cdn.discordapp.com/emojis/899339351283105812.png?size=96" },
            { name: "fill", url: "https://cdn.discordapp.com/emojis/899339288636956752.gif?size=44" },
            { name: "empty", url: "https://cdn.discordapp.com/emojis/899340041229307966.png?size=44" },
            { name: "fillStart", url: "https://cdn.discordapp.com/emojis/899339278000222249.gif?size=44" },
            { name: "emptyEnd", url: "https://cdn.discordapp.com/emojis/899340050226118737.png?size=44" },
            { name: "fillEnd", url: "https://cdn.discordapp.com/emojis/862062197776580618.gif?size=96" },
            { name: "xp", url: "https://cdn.discordapp.com/emojis/838468875825446922.gif?v=1" },
            { name: "gulucuk", url: "https://cdn.discordapp.com/emojis/838469248602865735.png?v=1" },
            { name: "mesaj2", url: "https://cdn.discordapp.com/emojis/1014935837596733460.webp?size=96&quality=lossless" },
            { name: "altin", url: "https://cdn.discordapp.com/emojis/836694825243508756.gif?v=1" },
            { name: "altin2", url: "https://cdn.discordapp.com/emojis/836694821128372224.gif?v=1" },
            { name: "voice", url: "https://cdn.discordapp.com/emojis/1022986540286218291.webp?size=96&quality=lossless" },
            { name: "channel", url: "https://cdn.discordapp.com/emojis/1022986540286218291.webp?size=96&quality=lossless" },
            { name: "wizardspotify", url: "https://cdn.discordapp.com/emojis/899337292840312912.png?size=44" },
            { name: "wizardnetflix", url: "https://cdn.discordapp.com/emojis/941993358518284298.webp?size=96&quality=lossless" },
            { name: "wizardexxen", url: "https://cdn.discordapp.com/emojis/900396713116835900.png?size=44" },
            { name: "wizardblutv", url: "https://cdn.discordapp.com/emojis/900396707362246666.png?size=44" },
            { name: "wizardnitro", url: "https://cdn.discordapp.com/emojis/941993742934614047.webp?size=96&quality=lossless" },
            { name: "wizardyoutube", url: "https://cdn.discordapp.com/emojis/941993963013935115.gif?size=96&quality=lossless" },
            { name: "slotgif", url: "https://cdn.discordapp.com/emojis/931686726567612426.gif?v=1" },
            { name: "slotpatlican", url: "https://cdn.discordapp.com/emojis/931686717902192660.png?size=44" },
            { name: "slotkiraz", url: "https://cdn.discordapp.com/emojis/931686708037185546.png?size=44" },
            { name: "slotkalp", url: "https://cdn.discordapp.com/emojis/931686698138603610.png?size=44" },
            { name: "partner", url: "https://cdn.discordapp.com/emojis/923691826374934618.webp?size=96&quality=lossless" },
            { name: "online", url: "https://cdn.discordapp.com/emojis/901829756603998269.webp?size=96&quality=lossless" },
            { name: "duyuru", url: "https://cdn.discordapp.com/emojis/840123951980347433.webp?size=96&quality=lossless" },
            { name: "kup", url: "https://cdn.discordapp.com/attachments/1072176765738438666/1079364938843303956/1079096700892881077.webp" },
            { name: "cizgi", url: "https://cdn.discordapp.com/emojis/916013869816745994.gif?size=96" },
            { name: "ileri", url: "https://cdn.discordapp.com/emojis/1084122771577122826.webp?size=96&quality=lossless" },
            { name: "geri", url: "https://cdn.discordapp.com/emojis/1084122741432668160.webp?size=96&quality=lossless" },
        ]
        const SayıEmojis = [
            { name: "sifir", url: "https://cdn.discordapp.com/emojis/943146617043828788.gif?size=96&quality=lossless" },
            { name: "bir", url: "https://cdn.discordapp.com/emojis/943147988375715861.gif?size=96&quality=lossless" },
            { name: "iki", url: "https://cdn.discordapp.com/emojis/943148029639278622.gif?size=96&quality=lossless" },
            { name: "uc", url: "https://cdn.discordapp.com/emojis/943148080025460766.gif?size=96&quality=lossless" },
            { name: "dort", url: "https://cdn.discordapp.com/emojis/943148147327262751.gif?size=96&quality=lossless" },
            { name: "bes", url: "https://cdn.discordapp.com/emojis/943148227753033809.gif?size=96&quality=lossless" },
            { name: "alti", url: "https://cdn.discordapp.com/emojis/943148271738707988.gif?size=96&quality=lossless" },
            { name: "yedi", url: "https://cdn.discordapp.com/emojis/943148318165442700.gif?size=96&quality=lossless" },
            { name: "sekiz", url: "https://cdn.discordapp.com/emojis/943148360368537620.gif?size=96&quality=lossless" },
            { name: "dokuz", url: "https://cdn.discordapp.com/emojis/943148402655510620.gif?size=96&quality=lossless" }
          ]
          emojis.forEach(async (x) => {
              if (interaction.guild.emojis.cache.find((e) => x.name === e.name)) return db.set(x.name, interaction.guild.emojis.cache.find((e) => x.name === e.name).toString());
              const emoji = await interaction.guild.emojis.create(x.url, x.name);
              await db.set(x.name, emoji.toString()); 
              message.channel.send({ content: `\`${x.name}\` isimli emoji oluşturuldu! (${emoji.toString()})`, ephemeral: true })

            })

            SayıEmojis.forEach(async (x) => {
              if (interaction.guild.emojis.cache.find((e) => x.name === e.name)) return db.set(x.name, interaction.guild.emojis.cache.find((e) => x.name === e.name).toString());
              const emoji = await interaction.guild.emojis.create(x.url, x.name);
              await db.set(x.name, emoji.toString()); 
              message.channel.send({ content: `\`${x.name}\` isimli sayı emojisi oluşturuldu! (${emoji.toString()})`, ephemeral: true })

            })
        }
  
      })

    }
  },
};