module.exports = {

Root: "962417173043753022",
Token: "",
BotVoice: "1072176377903714348",
prefix: ["."],
mongoURL: "",
BotClientID: "1072177649033674762",

GuildID:"1072176376825790607",
Root: ["962417173043753022"],
botStatus: ["Develope By Ramal"],
AltBaşlık: "Copyright By Ramal",

dmMessages: true,
LevelSystem: true,
  
messageDolar: 1,
voiceDolar: 1,
  
messageCount: 1,
messageCoin: 2,
voiceCount: 1,
voiceCoin: 4,
publicCoin: 4,
inviteCount: 1,
inviteCoin: 15,
taggedCoin: 25,
toplamsCoin: 5.5,
yetkiCoin: 30,
  
banlimit: 3,
jaillimit: 3,
warnlimit: 3,
chatmutelimit: 3,
voicemutelimit: 3

}