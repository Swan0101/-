module.exports = {
    green: `green`,
    red: `red`,

}
