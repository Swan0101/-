Ozi Pm2 V13 Botlarıdır 

Botun başkasına satılma veyahut paylaşılma durumunda yasal yollardan dava hakkım bulunmaktadır..

Botunuzu güle güle kullanınız <3

Bot çalıştırma: pm2 start app.config.js